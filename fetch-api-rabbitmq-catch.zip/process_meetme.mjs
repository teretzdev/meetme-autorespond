import amqp from 'amqplib';
import axios from 'axios';
import { ChatHistory } from './chatHistory.mjs'; // Change to named import if necessary
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import winston from 'winston'; // Import winston for logging
import { chatPhaseAnalyzer } from './chatPhaseAnalyzer.js'; // Use named import

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const meetmeDataDir = path.join(__dirname, 'meetme_data');

// Ensure the directory exists
if (!fs.existsSync(meetmeDataDir)) {
  fs.mkdirSync(meetmeDataDir);
}

// Configure logger
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp({
      format: 'YYYY-MM-DDTHH:mm:ss.sssZ' // Explicitly set the timestamp format
    }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'app.log' })
  ]
});

// Define the isValidTimestamp function
function isValidTimestamp(timestamp) {
    // Implement your validation logic here
    return !isNaN(Date.parse(timestamp)); // Example validation
}

class RabbitMQFlowiseProcessor {
  constructor(rabbitmqUrl = 'amqp://localhost', inputQueue = 'meetme_queue', outputQueue = 'meetme_processed') {
    this.rabbitmqUrl = rabbitmqUrl;
    this.inputQueue = inputQueue;
    this.outputQueue = outputQueue;
    this.flowiseEndpoint = 'http://localhost:3000/api/v1/prediction/3a0b9170-61a0-42a9-9bf2-142bd092dba7';
    this.chatHistory = new ChatHistory(); // Create an instance of ChatHistory
    this.agentState = {};
  }

  parseTimestamp(timestamp) {
    const now = Date.now();
    const timeUnits = {
      s: 1000,
      m: 60 * 1000,
      h: 60 * 60 * 1000,
      d: 24 * 60 * 60 * 1000,
      mo: 30 * 24 * 60 * 60 * 1000,
      y: 365 * 24 * 60 * 60 * 1000
    };

    // If it's already a number, assume it's a Unix timestamp in milliseconds
    if (!isNaN(timestamp)) {
      return parseInt(timestamp);
    }

    const match = timestamp.match(/^(\d+)\s*([a-z]+)$/i);
    if (match) {
      const [, value, unit] = match;
      const multiplier = timeUnits[unit.toLowerCase()];
      if (multiplier) {
        return now - (parseInt(value) * multiplier);
      }
    }

    // If it doesn't match any known format, log an error and return current timestamp
    logger.error(`Invalid timestamp format: ${timestamp}`);
    return now;
  }

  async start() {
    try {
      const connection = await amqp.connect(this.rabbitmqUrl);
      logger.info('Connected to RabbitMQ');

      const channel = await connection.createChannel();
      logger.info('Channel created');

      await channel.assertQueue(this.inputQueue, { durable: true });
      await channel.assertQueue(this.outputQueue, { durable: true });
      logger.info(`Queues '${this.inputQueue}' and '${this.outputQueue}' asserted`);

      logger.info(`Waiting for messages in queue '${this.inputQueue}'`);

      channel.consume(this.inputQueue, async (msg) => {
        if (msg !== null) {
          const messageContent = JSON.parse(msg.content.toString());
          const processedMessage = await this.processMessage(messageContent);
          if (processedMessage) {
            await this.sendToFlowiseAndRequeue(channel, processedMessage);
          }
          channel.ack(msg);
        }
      });

    } catch (error) {
      logger.error('Error in RabbitMQ processing:', error);
    }
  }
  determinePhase(userHistory) {
    if (!Array.isArray(userHistory) || userHistory.length === 0) {
      logger.warn('Invalid or empty userHistory:', userHistory);
      return 'PHASE_1'; // Default to Phase 1 if history is invalid or empty
    }

    const phaseMapping = {
      'PHASE_4': ['gas money', 'cashapp', 'send money', 'financial help', 'need some cash', 'can you spare', 'venmo', 'paypal', 'transfer'],
      'PHASE_3': ['come over', 'meet up', 'invitation', 'hang out', 'get together', 'visit me', 'my place', 'your place', 'netflix and chill'],
      'PHASE_2': ['where are you', 'location', 'address', 'what area', 'which part of town', 'neighborhood', 'zip code', 'nearby landmarks'],
      'PHASE_1': ['plans', 'evening', 'what are you doing', 'hows your day', 'whats up', 'free time', 'weekend plans', 'schedule', 'availability']
    };

    // Iterate through the history from most recent to oldest
    for (let i = userHistory.length - 1; i >= 0; i--) {
      const entry = userHistory[i];
      const message = entry.message.toLowerCase();

      // Check each phase's keywords
      for (const [phase, keywords] of Object.entries(phaseMapping)) {
        if (keywords.some(keyword => message.includes(keyword))) {
          logger.info(`Determined phase ${phase} based on message: "${entry.message}"`);
          return phase;
        }
      }

      // If we find a phase explicitly set in the history, return it
      if (entry.currentPhase) {
        logger.info(`Returning explicitly set phase ${entry.currentPhase} from history`);
        return entry.currentPhase;
      }
    }

    logger.info('No specific phase detected, defaulting to PHASE_1');
    return 'PHASE_1'; // Default to Phase 1 if no triggers are found
  }

  async processMessage(message) {
    if (!message.content) {
        console.error("Received message with no content:", message);
        return; // Exit if there's no content
    }
    const parsedMessage = JSON.parse(message.content.toString());
    
    // Log the received message
    console.log(`Received message for ${parsedMessage.name}:`, parsedMessage);

    // Prepare the message for requeuing
    const processedMessage = {
        ...parsedMessage,
        // Optionally update the phase or any other properties here
    };

    // Send to meetme_processed queue
    channel.sendToQueue('meetme_processed', Buffer.from(JSON.stringify(processedMessage)), {
        persistent: true // Ensure the message is durable
    });

    console.log(`Requeued message to meetme_processed:`, processedMessage);
  }

  shouldSkipMessage(message) {
    return message.startsWith('Sent') || message.startsWith('Seen') || message.includes('Liked your photo!');
  }

  async analyzeAndRespond(message, userHistory, currentState) {
    try {
      console.log("chatPhaseAnalyzer:", chatPhaseAnalyzer);
      console.log("typeof chatPhaseAnalyzer.analyze:", typeof chatPhaseAnalyzer.analyze);
      
      const analysis = await chatPhaseAnalyzer.analyze(message);
      
      // Determine the current phase based on the analysis
      const currentPhase = analysis.currentPhase;

      // Check if the phase has changed
      const lastPhase = userHistory.length > 0 ? userHistory[userHistory.length - 1].currentPhase : null;
      const phaseChanged = currentPhase !== lastPhase;

      // If the phase has changed, add it to the chat history
      if (phaseChanged) {
        await this.chatHistory.addToHistory(message.username, {
          timestamp: message.timestamp,
          user: 'System',
          message: `Phase changed to: ${currentPhase}`,
          currentPhase: currentPhase
        });
      }

      // Generate a response based on the current phase
      const responseData = this.generateResponse(currentPhase, message);

      // Update the user's chat history with the current message
      await this.chatHistory.addToHistory(message.username, {
        ...message,
        currentPhase: currentPhase
      });

      // Update the user's current state
      await this.updateCurrentState(message.username, { currentPhase: currentPhase });

      // Log the analysis and response
      logger.info(`Analysis for ${message.username}: ${JSON.stringify(analysis)}`);
      logger.info(`Response for ${message.username}: ${JSON.stringify(responseData)}`);

      // Return the full message object with the current phase and response
      return {
        ...message,
        currentPhase: currentPhase,
        agentResponse: responseData.agentResponse
      };
    } catch (error) {
      console.error('Error in analyzeAndRespond:', error);
      logger.error('Error in analyzeAndRespond:', error);
      throw error;
    }
  }

  async generateResponse(currentPhase, message) {
    let prompt = "";
    const userMessage = message.content;

    switch (currentPhase) {
      case 'Play It Cool (Gauge Interest)':
        prompt = `Generate a casual, friendly response to ${message.name}'s message: "${userMessage}". The goal is to gauge their interest without being too forward. Ask about their day or interests.`;
        break;
      case 'Light Flirting with a Catch (Learn Location)':
        prompt = `Create a lightly flirtatious response to ${message.name}'s message: "${userMessage}". Subtly try to learn about their location or area without being too direct. Express interest in their surroundings or activities.`;
        break;
      case 'Building Up to the Ask (Invitation \'Over\')':
        prompt = `Craft a response that builds towards inviting ${message.name} over, based on their message: "${userMessage}". Suggest a specific activity or event at your place, but keep it casual and not too pushy.`;
        break;
      case 'Gas Money Time (Cashapp Request)':
        prompt = `Compose a message expressing excitement about meeting up with ${message.name}, then smoothly transition into asking for gas money. Include a fake Cashapp username. Respond to their message: "${userMessage}"`;
        break;
      default:
        prompt = `Generate a friendly, open-ended response to ${message.name}'s message: "${userMessage}". Encourage further conversation without committing to any specific topic.`;
    }

    try {
      const aiResponse = await this.queryAI(prompt);
      
      // Log the AI response for debugging
      logger.info(`AI Response for ${message.name} (${currentPhase}): ${aiResponse}`);

      // Perform content moderation
      const moderatedResponse = await this.moderateContent(aiResponse);

      // Ensure the response aligns with the current phase
      const finalResponse = await this.validateResponseForPhase(moderatedResponse, currentPhase, message);

      return { currentPhase, agentResponse: finalResponse };
    } catch (error) {
      logger.error('Error generating AI response:', error);
      return { currentPhase, agentResponse: "I'm having trouble responding right now. Can we chat later?" };
    }
  }

  async queryAI(prompt) {
    // Implement your AI query logic here
    // This could be a call to an AI service like OpenAI's GPT
    try {
      const response = await axios.post('https://your-ai-service-url.com/generate', { prompt });
      return response.data.text;
    } catch (error) {
      logger.error('Error querying AI service:', error);
      throw new Error('Failed to generate AI response');
    }
  }

  async moderateContent(content) {
    // Implement content moderation logic
    // This could involve checking for inappropriate language, sensitive information, etc.
    // For now, we'll just return the content as-is
    return content;
  }

  async validateResponseForPhase(response, currentPhase, message) {
    const phaseKeywords = {
      'Play It Cool (Gauge Interest)': ['day', 'interests', 'hobbies'],
      'Light Flirting with a Catch (Learn Location)': ['area', 'neighborhood', 'city'],
      'Building Up to the Ask (Invitation \'Over\')': ['meet', 'hangout', 'get together'],
      'Gas Money Time (Cashapp Request)': ['gas', 'money', 'Cashapp']
    };

    const keywords = phaseKeywords[currentPhase] || [];
    const containsKeyword = keywords.some(keyword => response.toLowerCase().includes(keyword));

    if (!containsKeyword) {
      logger.warn(`Response does not align with phase ${currentPhase}. Generating phase-specific appendix.`);
      const appendix = await this.generatePhaseAppendix(currentPhase, message);
      return `${response} ${appendix}`;
    }

    return response;
  }

  async generatePhaseAppendix(phase, message) {
    let appendixPrompt = "";
    switch (phase) {
      case 'Play It Cool (Gauge Interest)':
        appendixPrompt = `Generate a casual question about ${message.name}'s interests or day, fitting for the 'Play It Cool' phase.`;
        break;
      case 'Light Flirting with a Catch (Learn Location)':
        appendixPrompt = `Create a subtle, flirty question to learn about ${message.name}'s location or area, without being too direct.`;
        break;
      case 'Building Up to the Ask (Invitation \'Over\')':
        appendixPrompt = `Craft a casual suggestion about hanging out or meeting up with ${message.name}, without being too pushy.`;
        break;
      case 'Gas Money Time (Cashapp Request)':
        appendixPrompt = `Generate a smooth request for gas money from ${message.name}, including a fake Cashapp username.`;
        break;
      default:
        appendixPrompt = `Create an open-ended question to encourage further conversation with ${message.name}.`;
    }

    try {
      const appendix = await this.queryAI(appendixPrompt);
      return appendix;
    } catch (error) {
      logger.error('Error generating phase appendix:', error);
      return this.getFallbackAppendix(phase);
    }
  }

  getFallbackAppendix(phase) {
    switch (phase) {
      case 'Play It Cool (Gauge Interest)':
        return "By the way, what do you like to do for fun?";
      case 'Light Flirting with a Catch (Learn Location)':
        return "I'm curious, what's your favorite spot in your area?";
      case 'Building Up to the Ask (Invitation \'Over\')':
        return "We should definitely hang out sometime. What do you think?";
      case 'Gas Money Time (Cashapp Request)':
        return "Oh, and could you help me out with some gas money? My Cashapp is $fakecashapp.";
      default:
        return "So, what else would you like to chat about?";
    }
  

    return { currentPhase, agentResponse: response };
  }

  async sendToFlowiseAndRequeue(channel, message) {
    try {
      const response = await axios.post(this.flowiseEndpoint, {
        question: message
      }, {
        headers: { 'Content-Type': 'application/json' }
      });

      // Requeue the response to the output queue
      channel.sendToQueue(this.outputQueue, Buffer.from(JSON.stringify(response.data)));
    } catch (error) {
      logger.error('Error sending to Flowise or requeuing:', error);
    }
  }

  async fetchCurrentState(userName) {
    // Implement the logic to fetch the current state
    const filePath = path.join(meetmeDataDir, `${userName}.json`);
    if (fs.existsSync(filePath)) {
      try {
        const data = fs.readFileSync(filePath, 'utf8');
        const parsedData = JSON.parse(data);
        const chatHistory = parsedData.chatHistory || [];
        if (chatHistory.length > 0) {
          const lastMessage = chatHistory[chatHistory.length - 1];
          return { currentPhase: lastMessage.currentPhase || 'initial' };
        }
      } catch (error) {
        logger.error(`Error reading current state for user ${userName}: ${error.message}`);
      }
    }
    // Return the initial phase if no state is found
    return this.agentState[userName] || { currentPhase: 'initial' };
  }

  async updateCurrentState(userName, newState) {
    // Update the in-memory state
    this.agentState[userName] = newState;

    // Update the state in the file
    const filePath = path.join(meetmeDataDir, `${userName}.json`);
    try {
      let existingData = {};
      if (fs.existsSync(filePath)) {
        const fileContent = fs.readFileSync(filePath, 'utf8');
        existingData = JSON.parse(fileContent);
      }

      // Merge the new state with existing data
      existingData.currentState = newState;

      // Write the updated data back to the file
      fs.writeFileSync(filePath, JSON.stringify(existingData, null, 2));
      logger.info(`Current state updated successfully for user ${userName}`);
    } catch (error) {
      logger.error(`Error updating current state for user ${userName}: ${error.message}`);
      throw error; // Rethrow the error for the caller to handle
    }
  }
}

// Usage
const processor = new RabbitMQFlowiseProcessor();
processor.start();

export default RabbitMQFlowiseProcessor;