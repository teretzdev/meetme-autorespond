import { authorize } from './src/auth/googleAuth.js';
import { setupDatabase, setupRabbitMQ } from './src/utils/setup.js';
import { initializeBrowser, closeBrowser, loginToMeetMe, sendReply } from './src/services/meetmeService.js';
import logger from './src/utils/logger.js';

async function sendProcessedReplies(db, channel, authClient) {
  logger.info('sendProcessedReplies function started');
  const { browser, page } = await initializeBrowser();
  const isLoggedIn = await loginToMeetMe(page, config.MEETME_USERNAME, config.MEETME_PASSWORD);
  if (!isLoggedIn) throw new Error('Login failed');

  channel.consume('replies_to_send', async (msg) => {
    if (msg !== null) {
      const reply = JSON.parse(msg.content.toString());
      try {
        logger.info(`Sending reply for message ${reply.id}`);
        const success = await sendReply(page, reply.reply, reply.href);
        if (success) {
          await db.run("UPDATE messages SET status = 'sent' WHERE id = ?", reply.id);
          channel.ack(msg);
          logger.info(`Reply sent successfully for message ${reply.id}`);
        } else {
          throw new Error('Failed to send reply');
        }
      } catch (error) {
        logger.error(`Error sending reply for message ${reply.id}: ${error.message}`);
        await db.run("UPDATE messages SET status = 'error' WHERE id = ?", reply.id);
        channel.ack(msg);
      }
    }
  });
  logger.info('sendProcessedReplies function completed');
}


async function startSending() {
  try {
    logger.info('startSending function started');
    const authClient = await authorize();
    const db = await setupDatabase();
    const { channel } = await setupRabbitMQ();
    await sendProcessedReplies(db, channel, authClient);
    logger.info('startSending function completed');
  } catch (error) {
    logger.error(`Error in sending replies: ${error.message}`, { stack: error.stack });
  }
}

startSending();