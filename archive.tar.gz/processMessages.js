import { authorize } from './src/auth/googleAuth.js';
import { setupDatabase, setupRabbitMQ } from './src/utils/setup.js';
import { queryJessAI } from './src/services/jessAI.js';
import { updateChatHistory, formatChatHistory } from './src/services/sheetService.js';
import logger from './src/utils/logger.js';

async function processMessages(db, channel, authClient) {
  channel.consume('messages_to_process', async (msg) => {
    if (msg !== null) {
      const message = JSON.parse(msg.content.toString());
      try {
        logger.info(`Processing message ${message.id}`);
        const userHistory = await db.all("SELECT * FROM messages WHERE user = ?", message.username);
        const formattedHistory = formatChatHistory(userHistory);
        
        const aiResponse = await queryJessAI(message.shortMessage, formattedHistory);
        logger.info(`AI Response for user ${message.username}: ${JSON.stringify(aiResponse)}`);
        
        await db.run("UPDATE messages SET reply_to_send = ?, status = 'processed' WHERE id = ?", [aiResponse.message, message.id]);
        
        const updates = [[
          message.username,
          message.timeSent,
          message.shortMessage,
          message.href,
          aiResponse.message,
          'processed'
        ]];
        await updateChatHistory(authClient, updates);
        
        channel.sendToQueue('replies_to_send', Buffer.from(JSON.stringify({
          id: message.id,
          href: message.href,
          reply: aiResponse.message
        })), { persistent: true });
        
        channel.ack(msg);
      } catch (error) {
        logger.error(`Error processing message ${message.id}: ${error.message}`);
        await db.run("UPDATE messages SET status = 'error' WHERE id = ?", message.id);
        channel.ack(msg);
      }
    }
  });
}

async function startProcessing() {
  try {
    logger.info('Starting message processing');
    const authClient = await authorize();
    const db = await setupDatabase();
    const { channel } = await setupRabbitMQ();
    await processMessages(db, channel, authClient);
  } catch (error) {
    logger.error(`Error in message processing: ${error.message}`, { stack: error.stack });
  }
}

startProcessing();