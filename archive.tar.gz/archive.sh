#!/bin/bash

# Archive the current directory and all subdirectories
tar -czvf archive.tar.gz ./*

echo "Archive created: archive.tar.gz"
